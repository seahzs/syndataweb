"""
Coupon purchase prediction dataset data pre-processing.

Achieved from https://www.kaggle.com/competitions/coupon-purchase-prediction/data.
"""

from .processor import COUPON_PROCESSORS, COUPON_META_CONSTRUCTORS, COUPON_PROCESS_NAME_MAP, CouponProcessor


__all__ = (
    'COUPON_PROCESSORS',
    'COUPON_META_CONSTRUCTORS',
    'COUPON_PROCESS_NAME_MAP',
    'CouponProcessor'
)