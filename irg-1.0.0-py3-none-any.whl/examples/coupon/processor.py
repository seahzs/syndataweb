import os
import shutil
from typing import Dict, Callable, Optional, List
from types import FunctionType

import pandas as pd

from ..processor import DatabaseProcessor
from . import data, metadata

COUPON_PROCESSORS: Dict[str, Callable] = {
    'locations': data.locations,
    'users': data.users,
    'coupons': data.coupons,
    'purchases': data.purchases,
}
"""Coupon prediction table data processors."""

COUPON_META_CONSTRUCTORS: Dict[str, Callable] = {
    'locations': metadata.locations,
    'users': metadata.users,
    'coupons': metadata.coupons,
    'purchases': metadata.purchases,
}
"""Coupon prediction metadata constructors for each table."""

COUPON_PROCESS_NAME_MAP: Dict[str, str] = {
    'locations': 'prefecture_locations',
    'users': 'user_list',
    'coupons': 'coupon_list_train',
    'purchases': 'coupon_detail_train',
}
"""Coupon prediction source data file names (without extension) for all tables."""


class CouponProcessor(DatabaseProcessor):
    """Data processor for Coupon prediction database."""
    def __init__(self, src_data_dir: str, data_dir: str, meta_dir: str, out: str, tables: Optional[List[str]] = None):
        """
        **Args**:

        Arguments to `DatabaseProcessor`.
        If tables is not specified, all recognized tables are processed.
        """
        if tables is None or len(tables) == 0:
            tables = [*COUPON_PROCESSORS]
        super().__init__('coupon', src_data_dir, data_dir, meta_dir, tables, out)

    @property
    def _table_data_processors(self) -> Dict[str, FunctionType]:
        return COUPON_PROCESSORS

    @property
    def _table_src_name_map(self) -> Dict[str, str]:
        return COUPON_PROCESS_NAME_MAP

    @property
    def _table_metadata_constructors(self) -> Dict[str, FunctionType]:
        return COUPON_META_CONSTRUCTORS

    @property
    def _source_encoding(self) -> Optional[str]:
        return None

    def postprocess(self, output_dir: Optional[str] = None, sample: Optional[int] = None):
        if sample is not None:
            has_users = False
            has_coupons = False

            if 'users' in self._tables:
                users_table = pd.read_pickle(os.path.join(self._data_dir, 'users.pkl'))
                users = users_table.sample(n=sample).reset_index(drop=True)
                users.to_pickle(os.path.join(output_dir, 'users.pkl'))
                all_users = set(users['USER_ID_hash'])
                has_users = True

            if 'coupons' in self._tables and 'users' not in self._tables:
                coupon_table = pd.read_pickle(os.path.join(self._data_dir, 'coupons.pkl'))
                coupons = coupon_table.sample(n=sample)
                all_coupons = set(coupons['COUPON_ID_hash'])
                has_coupons = False

            if 'purchases' in self._tables:
                purchase_table = pd.read_pickle(os.path.join(self._data_dir, 'purchases.pkl'))
                if has_coupons:
                    purchase_table = purchase_table[purchase_table['COUPON_ID_hash'].isin(all_coupons)]\
                        .reset_index(drop=True)
                if has_users:
                    purchase_table = purchase_table[purchase_table['USER_ID_hash'].isin(all_users)] \
                        .reset_index(drop=True)
                    all_coupons = set(purchase_table['COUPON_ID_hash'])
                    all_coupons = pd.Series([*all_coupons]).sample(n=sample)
                    all_coupons = set(all_coupons)
                purchase_table.to_pickle(os.path.join(output_dir, 'purchases.pkl'))

            if 'coupons' in self._tables:
                coupon_table = pd.read_pickle(os.path.join(self._data_dir, 'coupons.pkl'))
                coupons = coupon_table[coupon_table['COUPON_ID_hash'].isin(all_coupons)].reset_index(drop=True)
                coupons.to_pickle(os.path.join(output_dir, 'coupons.pkl'))

        elif output_dir is not None:
            shutil.copytree(self._data_dir, output_dir, dirs_exist_ok=True)
