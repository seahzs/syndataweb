"""Table data processing."""
from datetime import datetime

import pandas as pd


__all__ = (
    'locations',
    'users',
    'coupons',
    'purchases',
)


def locations(src: pd.DataFrame) -> pd.DataFrame:
    return src.copy()


def users(src: pd.DataFrame) -> pd.DataFrame:
    src = src.astype({
        'REG_DATE': 'datetime64[ns]',
        'WITHDRAW_DATE': 'datetime64[ns]'
    })
    return src


def coupons(src: pd.DataFrame) -> pd.DataFrame:
    datetime_columns = ['DISPFROM', 'DISPEND', 'VALIDFROM', 'VALIDEND']
    return src.astype({
        c: 'datetime64[ns]' for c in datetime_columns
    })


def purchases(src: pd.DataFrame) -> pd.DataFrame:
    src = src.astype({'I_DATE': 'datetime64[ns]'})
    return src

