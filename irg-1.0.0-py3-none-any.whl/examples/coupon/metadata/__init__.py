"""FIFA match tables."""
from typing import Dict, Any
import pandas as pd

from irg.schema import Table

__all__ = (
    'locations',
    'users',
    'coupons',
    'purchases'
)


def locations(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['PREF_NAME', 'PREFECTUAL_OFFICE'])
    return {
        'attributes': attributes,
        'primary_keys': ['PREF_NAME'],
        'ttype': 'base'
    }


def users(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['PREF_NAME', 'USER_ID_hash'])
    return {
        'attributes': attributes,
        'primary_keys': ['USER_ID_hash'],
        'foreign_keys': [{
            'columns': ['PREF_NAME'],
            'parent': 'locations',
        }]
    }


def coupons(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['COUPON_ID_hash', 'ken_name'])
    return {
        'attributes': attributes,
        'primary_keys': ['COUPON_ID_hash'],
        'foreign_keys': [{
            'columns': ['ken_name'],
            'parent': 'locations',
            'parent_columns': ['PREF_NAME']
        }]
    }


def purchases(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['PURCHASEID_hash', 'USER_ID_hash', 'COUPON_ID_hash'])
    return {
        'attributes': attributes,
        'primary_keys': ['PURCHASEID_hash'],
        'foreign_keys': [{
            'columns': ['USER_ID_hash'],
            'parent': 'users'
        }, {
            'columns': ['COUPON_ID_hash'],
            'parent': 'coupons'
        }]
    }
