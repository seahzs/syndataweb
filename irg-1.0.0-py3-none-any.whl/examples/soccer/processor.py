import os
import shutil
from typing import Dict, Callable, Optional, List
from types import FunctionType

import pandas as pd

from ..processor import DatabaseProcessor
from . import data, metadata

SOCCER_PROCESSORS: Dict[str, Callable] = {
    'country': data.country,
    'league': data.league,
    'team': data.team,
    'team_attributes': data.team_attributes,
    'player': data.player,
    'player_attributes': data.player_attributes,
    'match': data.match
}
"""FIFA mathces table data processors."""

SOCCER_META_CONSTRUCTORS: Dict[str, Callable] = {
    'country': metadata.country,
    'league': metadata.league,
    'team': metadata.team,
    'team_attributes': metadata.team_attributes,
    'player': metadata.player,
    'player_attributes': metadata.player_attributes,
    'match': metadata.match
}
"""FIFA mathces metadata constructors for each table."""

SOCCER_PROCESS_NAME_MAP: Dict[str, str] = {
    'country': 'downloaded/Country',
    'league': 'downloaded/League',
    'team': 'downloaded/Team',
    'team_attributes': 'downloaded/Team_Attributes',
    'player': 'downloaded/Player',
    'player_attributes': 'downloaded/Player_Attributes',
    'match': 'downloaded/Match'
}
"""FIFA mathces source data file names (without extension) for all tables."""


class SoccerProcessor(DatabaseProcessor):
    """Data processor for FIFA mathces database."""
    def __init__(self, src_data_dir: str, data_dir: str, meta_dir: str, out: str, tables: Optional[List[str]] = None):
        """
        **Args**:

        Arguments to `DatabaseProcessor`.
        If tables is not specified, all recognized tables are processed.
        """
        if tables is None or len(tables) == 0:
            tables = [*SOCCER_PROCESSORS]
        super().__init__('soccer', src_data_dir, data_dir, meta_dir, tables, out)

    @property
    def _table_data_processors(self) -> Dict[str, FunctionType]:
        return SOCCER_PROCESSORS

    @property
    def _table_src_name_map(self) -> Dict[str, str]:
        return SOCCER_PROCESS_NAME_MAP

    @property
    def _table_metadata_constructors(self) -> Dict[str, FunctionType]:
        return SOCCER_META_CONSTRUCTORS

    @property
    def _source_encoding(self) -> Optional[str]:
        return None

    def postprocess(self, output_dir: Optional[str] = None, sample: Optional[int] = None):
        if sample is not None and 'player' in self._tables:
            player_table = pd.read_pickle(os.path.join(self._data_dir, 'player.pkl'))
            players = player_table.sample(n=sample).reset_index(drop=True)
            players.to_pickle(os.path.join(output_dir, 'players.pkl'))

            childs = ['player_attributes', 'match']
            for child in childs:
                table = pd.read_pickle(os.path.join(self._data_dir, f'{child}.pkl'))
                for c in table.columns:
                    if 'player_api_id' in c:
                        table = table[table[c].isin(players['player_api_id'])].reset_index(drop=True)
                table.to_pickle(os.path.join(output_dir, f'{child}.pkl'))
        elif output_dir is not None:
            shutil.copytree(self._data_dir, output_dir, dirs_exist_ok=True)
