"""Table data processing."""
from datetime import datetime

import pandas as pd


__all__ = (
    'country',
    'league',
    'team',
    'team_attributes',
    'player',
    'player_attributes',
    'match'
)


def country(src: pd.DataFrame) -> pd.DataFrame:
    return src.copy()


def league(src: pd.DataFrame) -> pd.DataFrame:
    return src.copy()


def team(src: pd.DataFrame) -> pd.DataFrame:
    return src[['team_api_id']]


def team_attributes(src: pd.DataFrame) -> pd.DataFrame:
    src = src.drop(columns=['team_fifa_api_id'])
    src['date'] = src['date'].apply(lambda x: f'DAT{x}')
    return src


def player(src: pd.DataFrame) -> pd.DataFrame:
    src = src.drop(columns=['player_name', 'player_fifa_api_id', 'id'])
    src = src.astype({'birthday': 'datetime64[ns]'})
    return src


def player_attributes(src: pd.DataFrame) -> pd.DataFrame:
    src = src.drop(columns=['player_fifa_api_id'])
    src = src.astype({'date': 'datetime64[ns]'})
    return src


def match(src: pd.DataFrame) -> pd.DataFrame:
    src = src.drop(columns=['id'] + [c for c in src.columns if 'player_X' in c or 'player_Y' in c])
    src['date'] = src['date'].astype('datetime64[ns]')
    src['season'] = src['season'].apply(
        lambda x: datetime(year=x[:4], month=1, day=1)
    ).astype('datetime64[ns]')
    return src