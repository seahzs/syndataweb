"""FIFA match tables."""
from typing import Dict, Any
import pandas as pd

from irg.schema import Table

__all__ = (
    'country',
    'league',
    'team',
    'team_attributes',
    'player',
    'player_attributes',
    'match'
)


def country(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['id'])
    return {
        'attributes': attributes,
        'primary_keys': ['id'],
        'ttype': 'base'
    }


def league(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['id', 'country_id'])
    return {
        'attributes': attributes,
        'primary_keys': ['id'],
        'ttype': 'base',
        'foreign_keys': [{
            'columns': ['country_id'],
            'parent': 'country',
            'parent_columns': ['id']
        }]
    }


def team(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['team_api_id'])
    return {
        'attributes': attributes,
        'primary_keys': ['id'],
        'ttype': 'base'
    }


def team_attributes(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['team_api_id', 'id'])
    return {
        'attributes': attributes,
        'primary_keys': ['team_api_id'],
        'foreign_keys': [{
            'columns': ['team_api_id'],
            'parent': 'team'
        }]
    }


def player(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['player_api_id'])
    return {
        'attributes': attributes,
        'primary_keys': ['player_api_id'],
    }


def player_attributes(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['id', 'player_api_id'])
    return {
        'attributes': attributes,
        'primary_keys': ['id'],
        'ttype': 'series',
        'series_id': 'date',
        'base_columns': ['player_api_id'],
        'foreign_keys': [{
            'columns': ['player_api_id'],
            'parent': 'player'
        }]
    }


def match(src: pd.DataFrame) -> Dict[str, Any]:
    players = [
        f'{t}_player_{i+1}' for t in ['home', 'away'] for i in range(11)
    ]
    attributes = Table.learn_meta(src, id_cols=[
        'country_id', 'league_id', 'match_api_id', 'home_team_api_id', 'away_team_api_id'
    ] + players)
    return {
        'attributes': attributes,
        'primary_keys': ['match_api_id'],
        'ttype': 'series',
        'series_id': 'stage',
        'base_columns': ['country_id', 'league_id', 'season'],
        'foreign_keys': [{
            'columns': ['country_id'],
            'parent': 'country',
            'parent_columns': ['id']
        }, {
            'columns': ['league_id'],
            'parent': 'league',
            'parent_columns': ['id']
        }, {
            'columns': ['home_team_api_id'],
            'parent': 'team',
            'parent_columns': ['team_api_id']
        }, {
            'columns': ['away_team_api_id'],
            'parent': 'team',
            'parent_columns': ['team_api_id']
        }] + [{
            'columns': [c],
            'parent': 'player',
            'parent_columns': ['player_api_id']
        } for c in players]
    }


