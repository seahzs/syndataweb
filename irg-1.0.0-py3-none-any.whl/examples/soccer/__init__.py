"""
Soccer match dataset data pre-processing.

Achieved from https://www.kaggle.com/datasets/hugomathien/soccer.
"""

from .processor import SOCCER_PROCESSORS, SOCCER_META_CONSTRUCTORS, SOCCER_PROCESS_NAME_MAP, SoccerProcessor


__all__ = (
    'SOCCER_PROCESSORS',
    'SOCCER_META_CONSTRUCTORS',
    'SOCCER_PROCESS_NAME_MAP',
    'SoccerProcessor'
)