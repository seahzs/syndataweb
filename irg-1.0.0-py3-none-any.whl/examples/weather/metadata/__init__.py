"""Ireland weather tables."""
from typing import Dict, Any
import pandas as pd

from irg.schema import Table

__all__ = (
    'station_list',
    'station_values'
)


def station_list(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['Station ID', 'Station name'])
    return {
        'attributes': attributes,
        'primary_keys': ['Station ID'],
        'ttype': 'base'
    }


def station_values(src: pd.DataFrame) -> Dict[str, Any]:
    attributes = Table.learn_meta(src, id_cols=['Station ID'])
    return {
        'attributes': attributes,
        'primary_keys': ['Station ID', 'date'],
        'foreign_keys': [{
            'columns': ['Station ID'],
            'parent': 'station_list'
        }],
        'ttype': 'series',
        'series_id': 'date',
        'base_columns': ['Station ID']
    }
