"""
Ireland weather dataset data pre-processing.

Achieved from https://www.kaggle.com/datasets/dariasvasileva/hourly-weather-data-in-ireland-from-24-stations.
"""

from .processor import WEATHER_PROCESSORS, WEATHER_META_CONSTRUCTORS, WEATHER_PROCESS_NAME_MAP, WeatherProcessor


__all__ = (
    'WEATHER_PROCESSORS',
    'WEATHER_META_CONSTRUCTORS',
    'WEATHER_PROCESS_NAME_MAP',
    'WeatherProcessor'
)