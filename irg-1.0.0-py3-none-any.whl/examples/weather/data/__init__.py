"""Table data processing."""
import pandas as pd


__all__ = (
    'station_list',
    'station_values'
)


def station_list(src: pd.DataFrame) -> pd.DataFrame:
    src = src.iloc[:, 1:]
    return src


def station_values(src: pd.DataFrame) -> pd.DataFrame:
    src = src.iloc[:, 1:]
    src = src.astype({'date': 'datetime64[ns]'})
    return src[src['date'].apply(lambda x: x.year == 2021)].reset_index(drop=True)
