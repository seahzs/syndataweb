import os
from datetime import datetime, timedelta
from typing import Dict, Callable, Optional, List
from types import FunctionType

import pandas as pd

from ..processor import DatabaseProcessor
from . import data, metadata

WEATHER_PROCESSORS: Dict[str, Callable] = {
    'station_list': data.station_list,
    'station_values': data.station_values
}
"""Ireland Weather table data processors."""

WEATHER_META_CONSTRUCTORS: Dict[str, Callable] = {
    'station_list': metadata.station_list,
    'station_values': metadata.station_values
}
"""Ireland Weather metadata constructors for each table."""

WEATHER_PROCESS_NAME_MAP: Dict[str, str] = {
    'station_list': 'downloaded/station_list',
    'station_values': 'downloaded/station_values'
}
"""Ireland Weather source data file names (without extension) for all tables."""


class WeatherProcessor(DatabaseProcessor):
    """Data processor for Ireland Weather database."""
    def __init__(self, src_data_dir: str, data_dir: str, meta_dir: str, out: str, tables: Optional[List[str]] = None):
        """
        **Args**:

        Arguments to `DatabaseProcessor`.
        If tables is not specified, all recognized tables are processed.
        """
        if tables is None or len(tables) == 0:
            tables = [*WEATHER_PROCESSORS]
        assert 'station_list' in tables
        if not os.path.exists(os.path.join(src_data_dir, 'downloaded', 'station_values.csv')):
            stations = pd.read_csv(os.path.join(src_data_dir, 'downloaded', 'station_list.csv'))
            all_station_values = []
            for _, row in stations.iterrows():
                station_values = pd.read_csv(os.path.join(src_data_dir, 'downloaded', 'Stations',
                                                          f'{row["Station ID"]}_{row["Station name"]}.csv'))
                station_values = data.station_values(station_values)
                station_values['Station ID'] = row['Station ID']
                all_station_values.append(station_values)
            station_values = pd.concat(all_station_values)
            station_values.to_csv(os.path.join(src_data_dir, 'downloaded', 'station_values.csv'))
        super().__init__('weather', src_data_dir, data_dir, meta_dir, tables, out)

    @property
    def _table_data_processors(self) -> Dict[str, FunctionType]:
        return WEATHER_PROCESSORS

    @property
    def _table_src_name_map(self) -> Dict[str, str]:
        return WEATHER_PROCESS_NAME_MAP

    @property
    def _table_metadata_constructors(self) -> Dict[str, FunctionType]:
        return WEATHER_META_CONSTRUCTORS

    @property
    def _source_encoding(self) -> Optional[str]:
        return None

    def postprocess(self, output_dir: Optional[str] = None, sample: Optional[int] = None):
        if sample is not None:
            values = pd.read_pickle(os.path.join(self._data_dir, 'station_values.pkl'))
            last_time = datetime(year=2021, month=1, day=1) + timedelta(hours=sample / 24)
            values = values[values['date'] <= last_time].reset_index(drop=True)
            values.to_pickle(os.path.join(output_dir, 'station_values.pkl'))

            stations = pd.read_pickle(os.path.join(self._data_dir, 'station_list.pkl'))
            stations.to_pickle(os.path.join(output_dir, 'station_list.pkl'))
        elif output_dir is not None:
            shutil.copytree(self._data_dir, output_dir, dirs_exist_ok=True)
