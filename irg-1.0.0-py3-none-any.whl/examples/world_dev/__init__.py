"""
World Bank dataset on world development pre-processing.

Achieved from https://www.kaggle.com/datasets/theworldbank/world-development-indicators.
"""