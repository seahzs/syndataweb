from typing import Dict

from ..processor import DatabaseProcessor

WORLD_DEV_PROCESS_NAME_MAP: Dict[str, str] = {
    'country': 'downloaded/WDICountry'
}


class SoccerProcessor(DatabaseProcessor):
    """Data processor for FIFA mathces database."""
    def __init__(self, src_data_dir: str, data_dir: str, meta_dir: str, out: str, tables: Optional[List[str]] = None):
        """
        **Args**:

        Arguments to `DatabaseProcessor`.
        If tables is not specified, all recognized tables are processed.
        """
        if tables is None or len(tables) == 0:
            tables = [*WORLD_DEV_PROCESSORS]
        super().__init__('soccer', src_data_dir, data_dir, meta_dir, tables, out)

    @property
    def _table_data_processors(self) -> Dict[str, FunctionType]:
        return WORLD_DEV_PROCESSORS

    @property
    def _table_src_name_map(self) -> Dict[str, str]:
        return WORLD_DEV_PROCESS_NAME_MAP

    @property
    def _table_metadata_constructors(self) -> Dict[str, FunctionType]:
        return WORLD_DEV_META_CONSTRUCTORS

    @property
    def _source_encoding(self) -> Optional[str]:
        return None

    def postprocess(self, output_dir: Optional[str] = None, sample: Optional[int] = None):
        if sample is not None and 'player' in self._tables:
            player_table = pd.read_pickle(os.path.join(self._data_dir, 'player.pkl'))
            players = player_table.sample(n=sample).reset_index(drop=True)
            players.to_pickle(os.path.join(output_dir, 'players.pkl'))

            childs = ['player_attributes', 'match']
            for child in childs:
                table = pd.read_pickle(os.path.join(self._data_dir, f'{child}.pkl'))
                for c in table.columns:
                    if 'player_api_id' in c:
                        table = table[table[c].isin(players['player_api_id'])].reset_index(drop=True)
                table.to_pickle(os.path.join(output_dir, f'{child}.pkl'))
        elif output_dir is not None:
            shutil.copytree(self._data_dir, output_dir, dirs_exist_ok=True)





