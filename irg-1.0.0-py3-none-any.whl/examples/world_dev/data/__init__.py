"""Table data processing."""
import numpy as np
import pandas as pd


def country(src: pd.DataFrame) -> pd.DataFrame:
    column_list = src.columns.tolist()
    src = src\
        .rename(columns={column_list[0]: 'Country Code'})\
        .drop(columns=['Short Name', 'Table Name', 'Long Name', '2-alpha code', 'WB-2 code', 'Special Notes',
                       column_list[-1]])
    currency_count = src['Currency Unit'].value_counts(dropna=False).to_dict()
    src['Currency Unit'] = src['Currency Unit'].apply(
        lambda x: x if currency_count[x] > 1 else 'Own'
    )
    src['National accounts base year'] = src['National accounts base year'].apply(
        lambda x: np.nan if pd.isnull(x) or x.startswith('Original chained') else int(x.split('/')[0])
    ).replace({20015: 2015}).astype('Int64')
    src['National accounts reference year'] = src['National accounts reference year'].apply(
        lambda x: np.nan if pd.isnull(x) else int(x.split('/')[0])
    ).astype('Int64')
    src['Alternative conversion factor start'] = src['Alternative conversion factor'].apply(
        lambda x: np.nan if pd.isnull(x) else int(x[:4])
    ).astype('Int64')
    src['Alternative conversion factor end'] = src['Alternative conversion factor'].apply(
        lambda x: np.nan if pd.isnull(x) else int(x) if len(x) == 4
        else int(x[-2:]) + 2000 if int(x[-2:]) < 30 else int(x[-2:]) + 1900
    ).astype('Int64')
    src['Latest population census'] = src['Latest population census'].apply(
        lambda x: np.nan if pd.isnull(x) else 2015 if x.startswith('G') else int(x[:4])
    ).astype('Int64')
    return src


def series(src: pd.DataFrame) -> pd.DataFrame:
    column_list = src.columns.tolist()
    src = src \
        .rename(columns={column_list[0]: 'Series Code'}) \
        .drop(columns=['Indicator Name', 'Short definition', 'Long definition', 'Limitations and exceptions',
                       'Notes from original source', 'General comments', 'Statistical concept and methodology',
                       'Development relevance', 'Related source links', 'Related indicators', 'Other web links',
                       column_list[-1]])
    src['Topic'] = src['Topic'].apply(
        lambda x: np.nan if pd.isnull(x) else x.split(':')[0]
    )
    src['Source'] = src['Source'].apply(
        lambda x: np.nan if pd.isnull(x) else 'WB' if 'world bank' in str(x).strip().lower() else 'others'
    )
    return src


def series_time(src: pd.DataFrame) -> pd.DataFrame:
    column_list = src.columns.tolist()
    src['Description'] = src['DESCRIPTION'].apply(
        lambda x: 'Interpolated using data for two ends of five years' if x.startswith('Interpolated using data for')
        else 'Averages for regions/groups' if x.startswith('Averages for regions/groups')
        else 'The data refers to 5-year' if x.startswith('The data refer to')
        else 'Reflects data available in PPAPI' if x.startswith('Reflects data that was available')
        else 'Data are weighted averages of 2 years' if x.startswith('Data are weighted averages')
        else 'Full coverage of vitamin A' if x.startswith('Full coverage with vitamin A') else x
    )
    src = src \
        .rename(columns={column_list[0]: 'Series Code'}) \
        .drop(columns=['DESCRIPTION', column_list[-1]])
    return src


def country_series(src: pd.DataFrame) -> pd.DataFrame:
    column_list = src.columns.tolist()
    src = src \
        .rename(columns={column_list[0]: 'Country Code', 'SeriesCode': 'Series Code'}) \
        .drop(columns=['DESCRIPTION', column_list[-1]])
    return src


def data(src: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(columns=['Country Code', 'Indicator Code', 'Year', 'Value'])
    for _, row in src.iterrows():
        for year in range(1960, 2019):
            value = row[str(year)]
            if pd.isnull(value):
                continue
            index = len(out)
            out.loc[index, 'Country Code'] = row['Country Code']
            out.loc[index, 'Indicator Code'] = row['Indicator Code']
            out.loc[index, 'Year'] = year
            out.loc[index, 'Value'] = value
    return out
