from typing import Dict, Any
import pandas as pd


def ges(src: pd.DataFrame) -> Dict[str, Any]:
    id_cols = ['student_token']

