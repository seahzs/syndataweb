"""Augment database."""

from typing import Optional, OrderedDict
import os
import logging

from ..schema import create_db, Database
from ..schema.database import DB_TYPE_BY_NAME
from ..utils.io import load_from

_LOGGER = logging.getLogger()


def augment(schema: Optional[OrderedDict] = None, file_path: Optional[str] = None, engine: Optional[str] = None,
            data_dir: str = '.', mtype: str = 'unrelated', save_db_to: Optional[str] = None, resume: bool = True,
            temp_cache: str = '.temp') \
        -> Database:
    """
    Augment database.

    **Args**:

    - `schema` to `mtype`: Arguments to [database creator](../schema/database#irg.schema.database.create)
    - `save_db_to` (`Optional[str]`): Save database to path.
    - `resume` (`bool`): Whether to use database saved at `save_db_to` or augmenting another time.
    - `temp_cache` (`str`): Directory path to save cached temporary files. Default is `.temp`.

    **Return**: Augmented database.
    """
    if save_db_to is not None and resume and os.path.exists(save_db_to):
        database = DB_TYPE_BY_NAME[mtype].load_from_dir(save_db_to, temp_cache)
        print('start from here', flush=True)
        if schema is None:
            schema = load_from(file_path)
        for table_name in schema:
            # if table_name == 'personal_data2': # TODO: reload
            #     import pandas as pd
            #     table = database[table_name]
            #     data = pd.read_pickle(os.path.join(database._data_dir, f'{table_name}.pkl'))
            #     print('reloaded', len(data), flush=True)
            #     table._length = 415
            #     loaded = table.data()
            #     data.to_pickle(table._data_path())
            #     print('so new is', len(table), len(loaded), flush=True)
            if not os.path.exists(os.path.join(save_db_to, f'{table_name}.pkl')):# or table_name == 'personal_data2': # TODO: personal data
                print('get from', table_name, save_db_to, flush=True)
                table = database.create_table(table_name, schema[table_name])
                table.save(os.path.join(save_db_to, f'{table_name}.pkl'))
                print('==== do add table', table_name)
            else:
                print('already there', table_name, os.path.join(save_db_to, f'{table_name}.pkl'), flush=True)
                database.update_columns(table_name)
        _LOGGER.info(f'Loaded database from {save_db_to}.')
    else:
        os.makedirs(temp_cache, exist_ok=True)
        print('===== create db')
        database = create_db(
            schema=schema,
            file_path=file_path,
            engine=engine,
            data_dir=data_dir,
            temp_cache=temp_cache,
            mtype=mtype
        )
        _LOGGER.info(f'Created database based on data in {data_dir}.')
        database.augment()
        _LOGGER.info('Augmented database.')
        if save_db_to is not None:
            database.save_to_dir(save_db_to)
            _LOGGER.info(f'Saved database to {save_db_to}.')
    return database
