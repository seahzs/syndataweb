"""
IRG (Incremental Relational Generator) Model and Training.
"""
