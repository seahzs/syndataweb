from itertools import combinations, chain
from typing import Collection, List, Tuple, Dict, Any, Optional

import numpy as np
import pandas as pd
from rdt import HyperTransformer
try:
    from rdt.transformers.categorical import OneHotEncodingTransformer
except:
    from rdt.transformers.categorical import OneHotEncoder as OneHotEncodingTransformer
try:
    from rdt.transformers.datetime import DatetimeRoundedTransformer
except:
    from rdt.transformers.datetime import OptimizedTimestampEncoder as DatetimeRoundedTransformer

from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.base import ClassifierMixin, RegressorMixin
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, mean_absolute_error, mean_squared_error
from sklearn.svm import LinearSVC, LinearSVR
from sdv.evaluation import evaluate as sdv_evaluate

from ...schema.attribute.encoding import EmbeddingAttribute


def _quantile(q):
    func = lambda x: np.quantile(x, q=q)
    func.__name__ = f'q{q}'
    return func


class SyntheticSeriesTableEvaluator:
    def __init__(self, real: pd.DataFrame, id_cols: Collection[str], base_cols: Collection[str], series_id: str,
                 context: int = 5, series_tokens: Optional[Collection[str]] = None,
                 embed_size: int = 10, embed_half_window: int = 2, embed_hidden_dim: int = 32):
        self._id_cols = id_cols
        self._series_id = series_id
        real = self._preprocess(real)
        series_tokens = series_tokens if series_tokens is not None else []
        self._embedders = {}
        self._real = real
        for c in series_tokens:
            attribute = EmbeddingAttribute(
                name=c,
                values=self._real[c],
                temp_cache=f'.temp/eval/{c}',
                embedding_dim=embed_size,
                half_window_size=embed_half_window,
                hidden_dim=embed_hidden_dim
            )
            self._embedders[c] = attribute
        encoded = self._encode_embeddings(real)
        self._categorical_columns = [c for c, t in real.dtypes.items() if str(t).lower().startswith('o')]

        self._transformer = HyperTransformer(default_data_type_transformers={
            'categorical': OneHotEncodingTransformer(),
            'datetime': DatetimeRoundedTransformer()
        })
        transformed = self._transformer.fit_transform(encoded)
        self._transformed_dim = {}
        self._transformed_names = {}
        base = 0
        for c in real.columns:
            if c in self._embedders:
                encoded_cols = self._embedders[c].transformed_columns
                transformed_cols = [y for x in encoded_cols for y in self._transformer.get_final_output_columns(x)]
            else:
                transformed_cols = self._transformer.get_final_output_columns(c)
            width = len(transformed_cols)
            self._transformed_dim[c] = (base, base + width)
            base += width
            self._transformed_names[c] = transformed_cols
        self._total_width = len(transformed.columns)
        assert base == self._total_width
        self._scaler = MinMaxScaler()
        self._normalized_real = pd.concat(self._scaler.fit_transform(transformed), axis=1)

        self._base_cols = [*base_cols] + ['.series_degree', '.series_base']
        self._base_norm_cols = [x for c in base_cols for x in self._transformed_names[c]]
        self._summary = self._construct_summary(self._normalized_real)

        self._trend = self._construct_trend(self._normalized_real)
        self._trend_summary = self._construct_summary(self._trend)

    def _construct_trend(self, data: pd.DataFrame) -> pd.DataFrame:
        out = []
        for idx, grp_data in data.groupby(self._base_norm_cols, dropna=False, as_index=False):
            series_part = grp_data.drop(columns=self._base_norm_cols)
            diff = pd.DataFrame(
                series_part[1:] - series_part[:-1],
                columns=series_part.columns
            )
            for c in self._base_norm_cols:
                diff[c] = grp_data[c].iloc[0]
            out.append(diff)
        return pd.concat(out, axis=1)

    def _construct_summary(self, data: pd.DataFrame) -> pd.DataFrame:
        out = []
        base_cols = set(self._base_norm_cols)
        grouped = data.groupby(self._base_norm_cols, dropna=False)
        aggregated = grouped.aggregate(['min', 'max', 'mean', 'std', 'median'] +
                                       [_quantile(q) for q in [0.05, 0.1, 0.25, 0.75, 0.9, 0.95]])
        for c in data.columns:
            if c in base_cols or c in self._categorical_columns:
                aggregated = aggregated.drop(columns=[(c, x) for x in aggregated[c].columns if x != 'mean'])
        return pd.concat(out, axis=1)

    def _preprocess(self, data: pd.DataFrame) -> pd.DataFrame:
        data = data.sort_values(by=[self._series_id]).drop(columns=self._id_cols)
        grouped = data.groupby(self._series_id)
        data['.series_degree'] = grouped[self._series_id].transform(len)
        data['.series_base'] = grouped[self._series_id].transform(min)
        return data

    def _transform_column(self, name: str, data: pd.Series) -> pd.DataFrame:
        if name in self._embedders:
            encoded = self._embedders[name].transform(data[name])
            encoded = encoded.rename(columns={
                t: f'{name}:{t}' for t in encoded.columns
            })
        else:
            encoded = pd.DataFrame({name: data})

        transformed = self._transformer.transform(encoded)
        placeholder = np.zeros(len(data), self._total_width)
        l, r = self._transformed_dim[name]
        placeholder[:, l:r] = transformed
        scaled = self._scaler.transform(placeholder)
        return scaled[:, l:r]

    def _transform_data(self, data: pd.DataFrame) -> pd.DataFrame:
        out = []
        for c in data.columns:
            out.append(self._transform_column(c, data[c]))
        return pd.concat(out, axis=1)

    def _encode_embeddings(self, data: pd.DataFrame) -> pd.DataFrame:
        out = []
        for c in data.columns:
            if c in self._embedders:
                encoded = self._embedders[c].transform(data[c])
                col_data = encoded.rename(columns={
                    t: f'{c}:{t}' for t in encoded.columns
                })
            else:
                col_data = pd.DataFrame({c: data[c]})
            out.append(col_data)
        return pd.concat(out, axis=1)

    def evaluate(self, fake: pd.DataFrame) -> Dict[str, Any]:
        fake = self._preprocess(fake)
        fake_normalized = self._construct_summary(self._transform_data(fake))
        fake_trend = self._construct_trend(fake_normalized)
        stat_result = {
            'original': self._sdv_evaluate(
                self._real.drop(columns=[self._series_id]),
                fake.drop(columns=[self._series_id])
            ),
            'summary': self._sdv_evaluate(self._summary, fake_normalized),
            'trend': self._sdv_evaluate(self._trend, fake_trend),
            'summary_trend': self._sdv_evaluate(
                self._trend_summary,
                self._construct_summary(fake_trend)
            )
        }

        return {
            'stat': stat_result
        }

    @staticmethod
    def _sdv_evaluate(real: pd.DataFrame, fake: pd.DataFrame) -> Dict[str, float]:
        stat_summary = {}
        eval_res = sdv_evaluate(
            fake, real,
            metrics=[
                'CSTest', 'KSTest', 'BNLogLikelihood', 'GMLogLikelihood', 'LogisticDetection'
            ], aggregate=False
        )
        for _, row in eval_res.iterrows():
            stat_summary[row['metric']] = row['raw_score']
        return stat_summary


class SyntheticSeriesTableEvaluator2:
    def __init__(self, real: pd.DataFrame, id_cols: Collection[str], base_cols: Collection[str], series_id: str,
                 context: int = 5, series_tokens: Optional[Collection[str]] = None, embed_size: int = 10,
                 embed_ctx_size: int = 4):
        self._transformer = HyperTransformer(default_data_type_transformers={
            'categorical': OneHotEncodingTransformer(),
            'datetime': DatetimeRoundedTransformer()
        })
        self._scaler = MinMaxScaler()

        self._columns = [c for c in real.columns if c not in id_cols]
        self._id_cols = id_cols
        self._base_cols = base_cols
        self._series_cols = [c for c in self._columns if c not in base_cols]
        self._series_id = series_id

        real = real.sort_values(by=[series_id])
        series_tokens = series_tokens if series_tokens is not None else []
        self._embedders = {}
        group_indexed = real.set_index([series_id])
        for c in series_tokens:
            attribute = EmbeddingAttribute(
                name=c,
                values=group_indexed,
                temp_cache=f'.temp/eval/{c}',
                embedding_dim=10,
                half_window_size=2,
                hidden_dim=32
            )
            self._embedders[c] = attribute
        self._degrees = self._calculate_degrees(real)

        self._real = self._encode(real)
        transformed = self._transformer.fit_transform(self._real)
        self._scaler.fit(transformed)
        acc = 0
        self._dimensions = {}
        for c in self._columns:
            if c in self._embedders:
                length = len(self._embedders[c].transformed_columns)
            else:
                length = len(self._transformer.get_final_output_columns(c))
            self._dimensions[c] = (acc, acc + length)
            acc += length
        self._total_transformed_dim = acc

        self._aggregated, self._groups = self._construct_summary_for_series(self._real)

        self._context = context
        self._real_x, self._eos_y, self._data_y = self._seq_data_construction(self._groups)

    def _encode(self, table: pd.DataFrame):
        out = []
        for c in self._columns:
            if c in self._embedders:
                encoded = self._embedders[c].transform(table[c])
                data = encoded.rename(columns={
                    t: f'{c}:{t}' for t in encoded.columns
                })
            else:
                data = pd.DataFrame({c: table[c]})
            out.append(data)
        return pd.concat(out, axis=1)

    def _calculate_degrees(self, data: pd.DataFrame) -> Dict[str, pd.Series]:
        degrees = {
            id_name: data[id_name].value_counts(dropna=False)
            for id_name in chain.from_iterable(combinations(self._id_cols, r) for r in range(1, len(self._id_cols)+1))
        }
        degrees['.series_degree'] = data[[*self._base_cols]].value_counts(dropna=False)
        return degrees

    def _scale_partial(self, data: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
        zeros = np.zeros(len(data), self._total_transformed_dim)
        for c in columns:
            l, r = self._dimensions[c]
            zeros[:, l:r] = data[self._transformer.get_final_output_columns(c)]
        series_scaled = self._scaler.transform(zeros)
        series_part = []
        for c in columns:
            l, r = self._dimensions[c]
            extracted = series_scaled[:, l:r]
            extracted = pd.DataFrame(extracted, columns=self._transformer.get_final_output_columns(c))
            series_part.append(extracted)
        return pd.concat(series_part, axis=1)

    def _construct_summary_for_series(self, data: pd.DataFrame) -> \
            (pd.DataFrame, List[Tuple[pd.Series, pd.Series, pd.Series, pd.DataFrame, pd.DataFrame]]):
        base_part = data[[*self._base_cols]]

        encoded = self._encode(data)
        series_part = self._transformer.transform(data[self._series_cols])
        series_part = self._scale_partial(series_part, self._series_cols)

        if self._series_id in self._id_cols:
            diff_part = pd.DataFrame()
        else:
            diff_part = pd.DataFrame({
                '.series_diff': [0] * len(data)
            })
            for _, group in data.groupby(by=self._base_cols, dropna=False):
                group_id = series_part.loc[group.index, f'{self._series_id}.value'].values
                diff_part.loc[group.index[1:], '.series_diff'] = group_id[1:] - group_id[:-1]

        combined = pd.concat([base_part, series_part, diff_part], axis=1)
        grouped = combined.groupby(by=self._base_cols, dropna=False, as_index=False)
        aggregated = grouped.aggregate(['min', 'max', 'mean', 'std', 'median'] +
                                       [_quantile(q) for q in [0.05, 0.1, 0.25, 0.75, 0.9, 0.95]])

        groups = []
        for _, group in grouped:
            base = group[self._base_cols].iloc[0]
            base_transformed = self._transformer.transform(group[self._base_cols].iloc[0:1]).iloc[0]
            raw = data.loc[group.index, self._series_cols]
            transformed = group[self._series_cols]
            groups.append((base, base_transformed, raw, transformed))
        return aggregated, groups

    def evaluate(self, fake: pd.DataFrame) -> Dict[str, Any]:
        fake = fake.sort_values(by=[self._series_id])
        degree_result = self._evaluate_degrees(fake)

        stat_result = self._sdv_evaluate(self._real, fake[self._columns])

        aggregated, groups = self._construct_summary_for_series(fake)
        agg_stat_result = self._sdv_evaluate(self._aggregated, aggregated)

        fake_x, eos_y, fake_y = self._seq_data_construction(groups)
        eos_result = self._eos_prediction(fake_x, eos_y)

        uni_ar_result = self._uni_ar(fake_x, fake_y)

        multi_ar_result = self._multi_ar(fake_x, fake_y)

        return {
            'length': degree_result,
            'stat': stat_result,
            'agg': agg_stat_result,
            'eos': eos_result,
            'uni-ar': uni_ar_result,
            'multi-ar': multi_ar_result
        }

    def _evaluate_degrees(self, fake: pd.DataFrame) -> Dict[str, Dict[str, float]]:
        fake_degrees = self._calculate_degrees(fake)
        degree_summary = {}
        for ids, real_vc in self._degrees.items():
            deg_eval = sdv_evaluate(
                fake_degrees[ids].to_frame(), real_vc.to_frame(),
                metrics=['KSTest', 'GMLogLikelihood'], aggregate=False
            )
            degree_summary['--'.join(ids)] = {
                'KS': deg_eval[deg_eval['metric'] == 'KSTest'].iloc[0]['raw_score'],
                'GM': deg_eval[deg_eval['metric'] == 'GMLogLikelihood'].iloc[0]['raw_score']
            }
        return degree_summary

    @staticmethod
    def _sdv_evaluate(real: pd.DataFrame, fake: pd.DataFrame) -> Dict[str, float]:
        stat_summary = {}
        eval_res = sdv_evaluate(
            fake, real,
            metrics=[
                'CSTest', 'KSTest', 'BNLogLikelihood', 'GMLogLikelihood', 'LogisticDetection'
            ], aggregate=False
        )
        for _, row in eval_res.iterrows():
            stat_summary[row['metric']] = row['raw_score']
        return stat_summary

    def _eos_prediction(self, fake_x: pd.DataFrame, fake_y: pd.Series) -> \
            Dict[str, Dict[str, float]]:
        log = LogisticRegression()
        log.fit(fake_x, fake_y)
        pred = log.predict(self._real_x)
        prob = log.predict_proba(self._real_x)
        log_result = {
            'acc': accuracy_score(self._eos_y, pred),
            'roc': roc_auc_score(self._eos_y, prob[:, log.classes_.index(1)]),
            'f1': f1_score(self._eos_y, pred)
        }

        svm = LinearSVC()
        svm.fit(fake_x, fake_y)
        pred = svm.predict(self._real_x)
        svm_result = {
            'acc': accuracy_score(self._eos_y, pred),
            'f1': f1_score(self._eos_y, pred)
        }
        return {
            'log': log_result,
            'svm': svm_result
        }

    def _seq_data_construction(self, groups: List[Tuple[pd.Series, pd.Series, pd.DataFrame, pd.DataFrame]]) -> \
            (pd.DataFrame, pd.Series, pd.DataFrame):
        out_x, eos_y, data_y = [], [], []
        for _, base, raw, data in groups:
            df = pd.DataFrame()
            for i in range(self._context):
                for c in self._series_cols:
                    df.loc[f'pre{i+1}:{c}'] = data.values[self._context-i-1:-i-1]
            for k, v in base.to_dict().items():
                df.loc[k] = v
            out_x.append(df)
            eos_y.append(pd.Series([0] * (len(data) - 1) + [1]))

            group_y_index = raw.iloc[len(df):].index
            group_y = {
                c: raw.loc[group_y_index, c] if self._transformer.get_final_output_columns(c) == 'categorical'
                else data.loc[group_y_index, f'{c}.value'].rename(c)
                for c in raw.columns
            }
            data_y.append(pd.DataFrame(group_y))
        out_x = pd.concat(out_x)
        eos_y = pd.concat(eos_y)
        data_y = pd.concat(data_y)
        return out_x, eos_y, data_y

    def _uni_ar(self, fake_x: pd.DataFrame, fake_y: pd.DataFrame) -> Dict[str, Dict[str, float]]:
        out = {}
        for c in self._series_cols:
            x_cols = [f'pre{i+1}:{c}' for i in range(self._context)]
            x = fake_x[x_cols]
            y = fake_y[c]
            test_x = self._real_x[x_cols]
            out[c] = self._supervised_score(c, x, y, test_x)

        return out

    def _supervised_score(self, c: str, x: pd.DataFrame, y: pd.Series, test_x: pd.DataFrame):
        perf = {}
        if self._transformer.field_data_types[c] == 'categorical':
            log = LogisticRegression()
            perf.update({
                f'log-{k}': v for k, v in self._clf_score(log, c, x, y, test_x)
            })
            svm = LinearSVC()
            perf.update({
                f'svm-{k}': v for k, v in self._clf_score(svm, c, x, y, test_x)
            })
        else:
            lin = LinearRegression()
            perf.update({
                f'lin-{k}': v for k, v in self._reg_score(lin, c, x, y, test_x)
            })
            svm = LinearSVR()
            perf.update({
                f'svm-{k}': v for k, v in self._reg_score(svm, c, x, y, test_x)
            })

    def _clf_score(self, model: ClassifierMixin, c: str, train_x: pd.DataFrame, y: pd.Series,
                   test_x: pd.DataFrame) -> Dict[str, float]:
        model.fit(train_x, y)
        pred = model.predict(test_x)
        return {
            'acc': accuracy_score(self._data_y[c], pred),
            'f1': f1_score(self._data_y[c], pred, average='macro')
        }

    def _reg_score(self, model: RegressorMixin, c: str, train_x: pd.DataFrame, y: pd.Series, test_x: pd.DataFrame) \
            -> Dict[str, float]:
        model.fit(train_x, y)
        pred = model.predict(test_x)
        return {
            'mae': mean_absolute_error(self._data_y[c], pred),
            'mse': mean_squared_error(self._data_y[c], pred)
        }

    def _multi_ar(self, fake_x: pd.DataFrame, fake_y: pd.DataFrame):
        out = {}
        for c in self._series_cols:
            y = fake_y[c]
            out[c] = self._supervised_score(c, fake_x, y, self._real_x)

        return out

