"""Series tabular table data structure that holds data and metadata of tables in a database."""
import os
import pickle
from typing import Collection, Dict, Iterable, List, Optional, Tuple, Union

import pandas as pd
import torch
from torch import Tensor
from tqdm import tqdm

from .table import Table, SyntheticTable, Variant, IdPolicy
from ...utils.errors import NotFittedError
from ...utils.misc import Data2D, Data2DName
from ...utils import SeriesInferenceOutput


class SeriesTable(Table):
    def __init__(self, name: str, series_id: str, base_cols: Optional[Collection[str]] = None,
                 id_cols: Optional[Iterable[str]] = None, attributes: Optional[Dict[str, dict]] = None,
                 **kwargs):
        if base_cols is None:
            base_cols = set()
        self._base_cols = base_cols
        self._series_id = series_id
        if id_cols is None:
            id_cols = set()
        if attributes is None:
            attributes = {}

        assert all(x not in attributes for x in {'.series_degree', '.series_increase', '.group_id', '.series_base'})
        attributes['.series_degree'] = {
            'type': 'numerical',
            'min_val': 0,
            'name': '.series_degree'
        }

        series_id_attr = {} if series_id not in attributes else attributes[series_id]
        increase_type = 'numerical'
        if attributes.get(series_id) is not None and series_id_attr.get('type') is not None:
            if series_id_attr['type'] in {'datetime', 'timedelta'}:
                increase_type = 'timedelta'
            elif series_id_attr['type'] == 'id':
                increase_type = 'id'
            elif series_id_attr['type'] != 'mumerical':
                raise NotImplementedError(f'Attribute of type {series_id_attr["type"]} cannot be used '
                                          f'as series ID. Please use something which difference can be calculated.')
        attributes['.series_increase'] = {
            'type': increase_type,
            'min_val': '0',
            'name': '.series_increase'
        }
        attributes['.series_base'] = {
            **{k: v for k, v in series_id_attr.items() if k != 'name'},
            'name': '.series_base'
        }

        self._index_groups = []
        need_fit = True if 'need_fit' not in kwargs else kwargs['need_fit']
        kwargs['need_fit'] = False
        super().__init__(name=name, ttype='series', id_cols=id_cols, attributes=attributes, **kwargs)
        self._need_fit = need_fit
        if need_fit and kwargs.get('data') is not None:
            self.fit(kwargs.get('data'), **{k: v for k, v in kwargs.items() if k != 'data'})
        print('base columns', self._base_cols, flush=True)
        print('known columns', self._known_cols, flush=True)

    def _processed_path(self) -> str:
        return os.path.join(self._temp_cache, 'grouped.pkl')

    def _index_group_path(self) -> str:
        return os.path.join(self._temp_cache, 'index_group.pkl')

    def _preprocess_data(self, data: pd.DataFrame) -> pd.DataFrame:
        if os.path.exists(self._processed_path()) and os.path.exists(self._index_group_path()):
            with open(self._index_group_path(), 'rb') as f:
                self._index_groups = pickle.load(f)
            return pd.read_pickle(self._processed_path())
        new_data = []
        acc = 0
        self._index_groups = []
        assert not ({'.series_degree', '.series_increase', '.group_id', '.series_base'} & set(data.columns))
        if self._base_cols:
            grouped = data.groupby([*self._base_cols], as_index=False)
        else:
            grouped = [(i, x.to_frame().T) for i, x in data.iterrows()]
        for _, group in tqdm(grouped, desc=f'Grouping series {self._name}'):
            sorted_group = group.sort_values(by=[self._series_id]).reset_index(drop=True)
            sorted_group.loc[:, '.series_degree'] = len(group)
            sorted_series_id = sorted_group[self._series_id].values
            sorted_group.loc[:, '.series_increase'] = 0
            sorted_group.loc[:, '.series_base'] = sorted_series_id[0]
            sorted_group.loc[1:, '.series_increase'] = sorted_series_id[1:] - sorted_series_id[:-1]
            sorted_group.loc[:, '.group_id'] = len(new_data)
            new_data.append(sorted_group)
            self._index_groups.append(pd.Index(range(acc, acc + len(group))))
            acc += len(group)
        data = pd.concat(new_data)
        data = data.set_index('.group_id')
        data.to_pickle(self._processed_path())
        with open(self._index_group_path(), 'wb') as f:
            pickle.dump(self._index_groups, f)
        return data

    def replace_data(self, new_data: pd.DataFrame, replace_attr: bool = True):
        new_data = self._preprocess_data(new_data)
        super().replace_data(new_data, replace_attr)

    def fit(self, data: pd.DataFrame, force_redo: bool = False, **kwargs):
        do_group = True
        if os.path.exists(self._data_path()):
            loaded_data = pd.read_pickle(self._data_path())
            if {'.series_degree', '.series_increase', '.series_base'} <= set(data.columns):
                do_group = False
                data = loaded_data

        if do_group:
            data = self._preprocess_data(data)
            data.to_pickle(self._data_path())
            print('index!!', data.index, flush=True)
        super().fit(data, force_redo, **kwargs)

    def data(self, variant: Variant = 'original', normalize: bool = False,
             with_id: IdPolicy = 'this', core_only: bool = False, return_as: Data2DName = 'pandas') -> Data2D:
        result = super().data(variant, normalize, with_id, core_only, return_as)
        if variant == 'degree':
            result = result[~result.index.duplicated()].reset_index(drop=True)
        return result

    def attr_for_deg(self, attr_name: str) -> bool:
        return attr_name in self._base_cols

    @classmethod
    def load(cls, path: str) -> "SeriesTable":
        with open(path, 'rb') as f:
            loaded = pickle.load(f)
            loaded.__class__ = SeriesTable
        loaded._temp_cache = '/Volumes/Expansion/IRGAN/.temp.nosync/real_db/tables/wifi'
        print('load series', path, loaded._temp_cache, flush=True)
        return loaded

    def _calculate_degrees(self, augmented: pd.DataFrame, degree: pd.DataFrame) -> (pd.DataFrame, pd.DataFrame):
        groupby_cols = [(self._name, col) for col in self._known_cols if col in self._base_cols]
        static_only = augmented[[(self._name, col) for col in self._base_cols]].drop_duplicates().reset_index(drop=True)
        static_only[('', 'degree')] = 0
        transformed = static_only.groupby(groupby_cols, dropna=False, as_index=False).count()
        assert set(groupby_cols) <= set(static_only.columns.tolist())
        assert set(groupby_cols) <= set(transformed.columns.tolist())
        deg_deg = degree.merge(transformed, on=groupby_cols, how='left')[('', 'degree')]
        assert len(deg_deg) == len(degree), f'{len(deg_deg)} {len(degree)}'
        degree[('', 'degree')] = deg_deg
        degree.loc[:, ('', 'degree')] = degree['', 'degree'].fillna(0)
        return augmented, degree

    def sg_data(self) -> Tuple[List[Tensor], List[Tensor], List[Tuple[int, int]],
                               Tuple[List[int], List[int]], Tuple[List[int], List[int]]]:
        print('called from sg data', flush=True)
        known, unknown, cat_dims = self.ptg_data()
        base_known_ids, base_unknown_ids, seq_known_ids, seq_unknown_ids = [], [], [], []
        acc_known, acc_unknown = 0, 0
        for (table, attr_name), attr in self._augmented_attributes.items():
            is_known = table != self._name or attr_name in self._known_cols
            is_in_base = table == self._name and attr_name in self._base_cols
            attr_width = len(attr.transformed_columns)
            if is_known:
                if is_in_base:
                    base_known_ids.extend(range(acc_known, acc_known + attr_width))
                seq_known_ids.extend(range(acc_known, acc_known + attr_width))
                acc_known += attr_width
            else:
                if is_in_base:
                    base_unknown_ids.extend(range(acc_known, acc_known + attr_width))
                    seq_known_ids.extend(range(acc_known, acc_known + attr_width))
                else:
                    seq_unknown_ids.extend(range(acc_known, acc_known + attr_width))
                acc_unknown += attr_width
        print('constructed', flush=True)
        print('index groups', len(self._index_groups))

        all_known, all_unknown = [], []
        for group in self._index_groups:
            all_known.append(known[group].mean(dim=0).float())
            all_unknown.append(unknown[group].float())
        return all_known, all_unknown, cat_dims, (base_known_ids, base_unknown_ids), (seq_known_ids, seq_unknown_ids)


class SyntheticSeriesTable(SeriesTable, SyntheticTable):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._real_cache = '.temp' if 'temp_cache' not in kwargs else kwargs['temp_cache']

    def _describer_path(self, idx: int) -> str:
        return os.path.join(self._real_cache, 'describers', f'describer{idx}.json')

    def _degree_attr_path(self) -> str:
        return os.path.join(self._real_cache, 'deg_attr')

    @classmethod
    def from_real(cls, table: SeriesTable, temp_cache: Optional[str] = None) -> "SyntheticSeriesTable":
        synthetic = SyntheticSeriesTable(
            name=table._name, ttype=table._ttype, need_fit=False,
            id_cols={*table._id_cols}, attributes=table._attr_meta,
            determinants=table._determinants, formulas=table._formulas,
            temp_cache=temp_cache if temp_cache is not None else table._temp_cache,
            series_id=table._series_id, base_cols=table._base_cols
        )
        return cls._copy_attributes(table, synthetic)

    @staticmethod
    def _copy_attributes(src: SeriesTable, target: "SyntheticSeriesTable") -> "SyntheticSeriesTable":
        super()._copy_attributes(src, target)
        target._index_groups = src._index_groups
        return target

    def shallow_copy(self) -> "SeriesTable":
        copied = super().shallow_copy()
        copied.__class__ = SeriesTable.__class__
        attr_to_copy = [
            '_fitted', '_attributes', '_length',
            '_known_cols', '_unknown_cols', '_augment_fitted',
            '_augmented_attributes', '_degree_attributes',
            '_aug_norm_by_attr_files', '_deg_norm_by_attr_files',
            '_augmented_ids', '_degree_ids', '_context_pca',
            '_base_cols', '_series_id', '_index_groups'
        ]
        for attr in attr_to_copy:
            setattr(copied, attr, getattr(self, attr))
        return copied

    def inverse_transform(self, normalized_core: Union[Tensor, SeriesInferenceOutput], replace_content: bool = True) \
            -> pd.DataFrame:
        if not self._fitted:
            raise NotFittedError('Table', 'inversely transforming predicted synthetic data')
        if isinstance(normalized_core, SeriesInferenceOutput):
            lengths = normalized_core.lengths
            normalized_core = normalized_core.output
            regroup = False
        else:
            lengths = [normalized_core.shape[1]]
            regroup = True

        columns, recovered_df, normalized_core = self._recover_core(normalized_core)

        if regroup:
            lengths = []
            new_data = []
            if self._base_cols:
                grouped = recovered_df.groupby([*self._base_cols], as_index=False, dropna=False)
            else:
                grouped = [(i, x.to_frame().T) for i, x in recovered_df.iterrows()]
            # for _, data in recovered_df.groupby([*self._base_cols], dropna=False):
            for _, data in tqdm(grouped, desc=f'Regrouping series {self._name}'):
                lengths.append(len(data))
                new_data.append(data)
            recovered_df = pd.concat(new_data, ignore_index=True).reset_index(drop=True)

        acc = 0
        for length in lengths:
            if self._series_id in self._id_cols:
                recovered_df.loc[acc:acc+length-1, self._series_id] = self._attributes[self._series_id]\
                    .generate(length).tolist()
            else:
                base = recovered_df.loc[acc:acc+length-1, '.series_base'].mean()
                recovered_df.loc[acc, self._series_id] = base
                for i in range(1, length):
                    recovered_df.loc[acc+i, self._series_id] = \
                        recovered_df.loc[acc+i-1, self._series_id] + recovered_df.loc[acc+i, '.series_increase']

        return self._post_inverse_transform(recovered_df, columns, replace_content, normalized_core)
