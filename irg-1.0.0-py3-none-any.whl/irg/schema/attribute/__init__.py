"""Attribute helpers, including transformers for normalization."""

from typing import Optional, Dict

from dateutil import parser
from jsonschema import validate
import pandas as pd

from .base import BaseAttribute
from .identity import SerialIDAttribute, RawAttribute
from .categorical import CategoricalAttribute
from .numerical import NumericalAttribute
from .datetime import DatetimeAttribute, TimedeltaAttribute
from .encoding import EncodingAttribute, EmbeddingAttribute
from ...utils.misc import reformat_datetime as _reformat_datetime

__all__ = (
    'BaseAttribute',
    'SerialIDAttribute',
    'RawAttribute',
    'CategoricalAttribute',
    'NumericalAttribute',
    'DatetimeAttribute',
    'TimedeltaAttribute',
    'EncodingAttribute',
    'EmbeddingAttribute',
    'create',
    'learn_meta'
)


_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': [
            'id',
            'raw',
            'categorical',
            'numerical',
            'datetime',
            'timedelta',
            'encoding',
            'embedding'
        ]}
    },
    'required': ['name', 'type']
}
_ID_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['id']},
        'generator': {
            'type': 'string',
            'pattern': r'^\s*lambda\s+[a-zA-Z_][a-zA-Z0-9_]*\s*:'
        }
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_RAW_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['raw']}
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_CAT_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['categorical']},
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_NUM_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['numerical']},
        'rounding': {'type': 'integer'},
        'min_val': {},
        'max_val': {},
        'max_clusters': {'type': 'integer'},
        'std_multiplier': {'type': 'integer'},
        'weight_threshold': {'type': 'number'}
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_DT_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['datetime']},
        'min_val': {'type': 'string'},
        'max_val': {'type': 'string'},
        'date_format': {'type': 'string'},
        'max_clusters': {'type': 'integer'},
        'std_multiplier': {'type': 'integer'},
        'weight_threshold': {'type': 'number'}
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_TD_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['timedelta']},
        'min_val': {'type': 'string'},
        'max_val': {'type': 'string'},
        'delta_format': {'type': 'string'},
        'max_clusters': {'type': 'integer'},
        'std_multiplier': {'type': 'integer'},
        'weight_threshold': {'type': 'number'}
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_ENC_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['encoding']},
        'vocab_file': {'type': 'string'},
        'engine': {'enum': ['json', 'pickle', 'yaml', 'torch']}
    },
    'required': ['name', 'type', 'vocab_file'],
    'additionalProperties': False
}
_EMB_ATTR_CONF = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string'},
        'type': {'enum': ['embedding']},
        'embedding_dim': {'type': 'integer'},
        'half_window_size': {'type': 'integer'},
        'hidden_dim': {'type': 'integer'},
        'lr': {'type': 'number'},
        'epoch': {'type': 'integer'},
        'batch_size': {'type': 'integer'},
    },
    'required': ['name', 'type'],
    'additionalProperties': False
}
_ATTR_CONF_BY_TYPE = {
    'id': _ID_ATTR_CONF,
    'raw': _RAW_ATTR_CONF,
    'categorical': _CAT_ATTR_CONF,
    'numerical': _NUM_ATTR_CONF,
    'datetime': _DT_ATTR_CONF,
    'timedelta': _TD_ATTR_CONF,
    'encoding': _ENC_ATTR_CONF,
    'embedding': _EMB_ATTR_CONF
}
_ATTR_TYPE_BY_NAME: Dict[str, BaseAttribute.__class__] = {
    'id': SerialIDAttribute,
    'raw': RawAttribute,
    'categorical': CategoricalAttribute,
    'numerical': NumericalAttribute,
    'datetime': DatetimeAttribute,
    'timedelta': TimedeltaAttribute,
    'encoding': EncodingAttribute,
    'embedding': EmbeddingAttribute
}
_DTYPE_MAP = {
    'categorical': ['categorical', 'object', 'str'],
    'numerical': ['int64', 'Int64', 'unit64', 'float64', 'Float64', 'int32', 'Int32', 'float32', 'Float32'],
    'datetime': ['datetime64', 'datetime64[ns]'],
    'timedelta': ['timedelta64', 'timedelta64[ns]']
}


def create(meta: dict, values: Optional[pd.Series] = None, temp_cache: str = '.temp') -> BaseAttribute:
    """
    Create attribute from meta.

    **Args**:

    - `meta` (`dict`): Metadata of the attribute described as a `dict`.
      It must have `name` and `type` key, where `type` can be 'id', 'categorical', 'numerical',
      'datetime', 'timedelta', and 'encoding'.
      It can have other keys based on the arguments to the corresponding type's attribute's constructor.
    - `values` Optional[pd.Series] (default `None`): Original value sto the attribute.
    - `temp_cache` (`str`): Directory path to save cached temporary files. Default is `.temp`.

    **Return**: The created attribute.
    """
    validate(meta, _ATTR_CONF)
    validate(meta, _ATTR_CONF_BY_TYPE[meta['type']])
    kwargs = {k: v for k, v in meta.items() if k != 'type'}
    return _ATTR_TYPE_BY_NAME[meta['type']](values=values, temp_cache=temp_cache, **kwargs)


def learn_meta(data: pd.Series, is_id: bool = False, name: str = None) -> dict:
    """
    Learn an attribute's metadata `dict` object.

    **Args**:

    - `data` (`pd.Series`): The data for this attribute.
    - `is_id` (`bool`): Whether this attribute is an ID attribute. Default is `False`.
    - `name` (`str`): Name of the attribute. If not provided, the returned `dict` will not have `'name'` field.

    **Return**: A `dict` object describing the attribute's metadata.
    """
    attr_meta = {}
    if name is not None:
        attr_meta['name'] = name

    if is_id:
        attr_meta['type'] = 'id'
        return attr_meta

    for dtype, choices in _DTYPE_MAP.items():
        if str(data.dtype) in choices:
            attr_meta['type'] = dtype
            _learn_property(dtype, data, attr_meta)
            return attr_meta
    raise ValueError(f'Meta cannot be learned for {name}.')


def _learn_property(dtype: str, data: pd.Series, attr_meta: dict):
    if dtype == 'categorical':
        try:
            for d in data:
                parser.parse(str(d))
            attr_meta['type'] = 'datetime'
            return
        except (OverflowError, ValueError):
            return

    elif dtype == 'numerical':
        for i in range(-20, 20):
            # rounded = data.apply(lambda x: x if pd.isnull(x) else round(x, i))
            # if rounded.equals(data):
            if all(round(x, i) == x for x in data.dropna().sample(n=min(data.notna().sum(), 200))):
                attr_meta['rounding'] = i
                return

    elif dtype == 'datetime':
        units_to_format = {
            'y': '%Y',
            'm': '-%m',
            'd': '-%d',
            'h': ' %H',
            'min': ':%M',
            's': ':%S',
        }
        format_str = ''
        for u, format_suffix in units_to_format.items():
            format_str += format_suffix
            # rounded = data.apply(lambda x: _reformat_datetime(x, format_str))
            # if rounded.equals(data):
            if all(_reformat_datetime(x, format_str) == x for x in data.sample(n=min(len(data), 200))):
                attr_meta['date_format'] = format_str
                return
        attr_meta['date_format'] = format_str + '.%f'
